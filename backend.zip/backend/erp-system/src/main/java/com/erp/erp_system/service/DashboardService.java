package com.erp.erp_system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.erp_system.dto.DashboardResponse;
import com.erp.erp_system.repository.CustomerRepository;
import com.erp.erp_system.repository.InventoryRepository;
import com.erp.erp_system.repository.ProductRepository;
import com.erp.erp_system.repository.PurchaseOrderRepository;
import com.erp.erp_system.repository.SalesOrderRepository;

@Service
public class DashboardService {

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private CustomerRepository customerRepo;

    @Autowired
    private SalesOrderRepository salesRepo;

    @Autowired
    private PurchaseOrderRepository purchaseRepo;

    @Autowired
    private InventoryRepository inventoryRepo;

    public DashboardResponse getStats(){

        DashboardResponse d = new DashboardResponse();

        d.setTotalProducts(productRepo.count());
        d.setTotalCustomers(customerRepo.count());
        d.setTotalSales(salesRepo.count());
        d.setTotalPurchases(purchaseRepo.count());
        d.setLowStock(inventoryRepo.findLowStock().size());

        return d;
    }
}