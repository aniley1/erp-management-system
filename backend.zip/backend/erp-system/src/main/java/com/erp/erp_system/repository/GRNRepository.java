package com.erp.erp_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erp.erp_system.entity.GRN;

public interface GRNRepository extends JpaRepository<GRN, Long>{

}