package com.erp.erp_system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.erp_system.entity.Inventory;
import com.erp.erp_system.repository.InventoryRepository;

@Service
public class InventoryService {

    @Autowired
    private InventoryRepository repo;

    public List<Inventory> getLowStockProducts(){

        return repo.findLowStock();
    }
}