package com.erp.erp_system.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.erp.erp_system.entity.Product;
import com.erp.erp_system.entity.PurchaseOrder;
import com.erp.erp_system.entity.SalesOrder;
import com.erp.erp_system.service.ReportsService;

@RestController
@RequestMapping("/api/reports")
public class ReportsController {

    @Autowired
    private ReportsService reportsService;

    // SALES REPORT
    @GetMapping("/sales")
    public List<SalesOrder> getSalesReport() {
        return reportsService.getSalesReport();
    }

    // PURCHASE REPORT
    @GetMapping("/purchase")
    public List<PurchaseOrder> purchaseReport() {
        return reportsService.getPurchaseReport();
    }

    // STOCK ALERT
    @GetMapping("/stock-alerts")
    public List<Product> stockAlerts() {
        return reportsService.getLowStockProducts();
    }

    // SALES BETWEEN DATES
    @GetMapping("/sales-by-date")
    public List<SalesOrder> salesByDate(
            @RequestParam String start,
            @RequestParam String end) {

        LocalDate startDate = LocalDate.parse(start);
        LocalDate endDate = LocalDate.parse(end);

        return reportsService.salesByDate(startDate, endDate);
    }
}