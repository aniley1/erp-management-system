package com.erp.erp_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erp.erp_system.entity.Invoice;

public interface InvoiceRepository extends JpaRepository<Invoice,Long>{

}