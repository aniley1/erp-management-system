package com.erp.erp_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.erp.erp_system.dto.PurchaseOrderRequest;
import com.erp.erp_system.entity.PurchaseOrder;
import com.erp.erp_system.service.PurchaseOrderService;

@RestController
@RequestMapping("/api/purchase-orders")
public class PurchaseOrderController {

    @Autowired
    private PurchaseOrderService service;

    @PostMapping
    public PurchaseOrder create(@RequestBody PurchaseOrderRequest request){
        return service.createOrder(request);
    }
}