package com.erp.erp_system.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.erp_system.entity.Invoice;
import com.erp.erp_system.entity.SalesOrder;
import com.erp.erp_system.repository.InvoiceRepository;
import com.erp.erp_system.repository.SalesOrderRepository;

@Service
public class InvoiceService {
	
	private final InvoiceRepository invoiceRepository;

    public InvoiceService(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }

    public Invoice save(Invoice invoice) {
        return invoiceRepository.save(invoice);
    }

    @Autowired
    private InvoiceRepository invoiceRepo;

    @Autowired
    private SalesOrderRepository salesOrderRepo;

    public Invoice generateInvoice(Long salesOrderId){

        SalesOrder order = salesOrderRepo.findById(salesOrderId).orElseThrow();

        Invoice invoice = new Invoice();

        invoice.setInvoiceDate(LocalDate.now());
        invoice.setSalesOrder(order);
        invoice.setAmount(order.getTotalAmount());

        return invoiceRepo.save(invoice);
    }
}