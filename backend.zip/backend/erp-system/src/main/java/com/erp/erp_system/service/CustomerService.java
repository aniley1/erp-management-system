package com.erp.erp_system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.erp_system.entity.Customer;
import com.erp.erp_system.repository.CustomerRepository;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository repo;

    public List<Customer> getAllCustomers(){
        return repo.findAll();
    }

    public Customer save(Customer c){
        return repo.save(c);
    }

    public void delete(Long id){
        repo.deleteById(id);
    }
}