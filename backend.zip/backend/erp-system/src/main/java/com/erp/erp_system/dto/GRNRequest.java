package com.erp.erp_system.dto;

import java.util.List;

public class GRNRequest {

    private Long purchaseOrderId;
    private List<GRNItemRequest> items;

    public Long getPurchaseOrderId() {
        return purchaseOrderId;
    }

    public void setPurchaseOrderId(Long purchaseOrderId) {
        this.purchaseOrderId = purchaseOrderId;
    }

    public List<GRNItemRequest> getItems() {
        return items;
    }

    public void setItems(List<GRNItemRequest> items) {
        this.items = items;
    }
}