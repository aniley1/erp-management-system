package com.erp.erp_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.erp.erp_system.entity.Inventory;
import com.erp.erp_system.service.InventoryService;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

    @Autowired
    private InventoryService service;

    @GetMapping("/low-stock")
    public List<Inventory> lowStock(){

        return service.getLowStockProducts();
    }
}