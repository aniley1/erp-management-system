package com.erp.erp_system.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.erp_system.dto.OrderItemRequest;
import com.erp.erp_system.dto.OrderRequest;
import com.erp.erp_system.entity.Customer;
import com.erp.erp_system.entity.Order;
import com.erp.erp_system.entity.OrderItem;
import com.erp.erp_system.entity.Product;
import com.erp.erp_system.repository.CustomerRepository;
import com.erp.erp_system.repository.OrderRepository;
import com.erp.erp_system.repository.ProductRepository;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ProductRepository productRepository;

    public Order createOrder(OrderRequest request) {

        Customer customer = customerRepository.findById(request.getCustomerId()).orElseThrow();

        Order order = new Order();
        order.setCustomer(customer);
        order.setOrderDate(LocalDate.now());

        List<OrderItem> orderItems = new ArrayList<>();
        double total = 0;

        for (OrderItemRequest itemRequest : request.getItems()) {

            Product product = productRepository.findById(itemRequest.getProductId()).orElseThrow();

            OrderItem item = new OrderItem();
            item.setProduct(product);
            item.setQuantity(itemRequest.getQuantity());

            double price = product.getPrice() * itemRequest.getQuantity();
            item.setPrice(price);

            item.setOrder(order);

            total += price;

            orderItems.add(item);
        }

        order.setItems(orderItems);
        order.setTotalAmount(total);

        return orderRepository.save(order);
    }
}