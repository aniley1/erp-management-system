package com.erp.erp_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erp.erp_system.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {

    Role findByName(String name);

}