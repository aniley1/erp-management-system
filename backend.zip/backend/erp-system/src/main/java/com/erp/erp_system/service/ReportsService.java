package com.erp.erp_system.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.erp_system.entity.Product;
import com.erp.erp_system.entity.PurchaseOrder;
import com.erp.erp_system.entity.SalesOrder;
import com.erp.erp_system.repository.ProductRepository;
import com.erp.erp_system.repository.PurchaseOrderRepository;
import com.erp.erp_system.repository.SalesOrderRepository;

@Service
public class ReportsService {

    @Autowired
    private SalesOrderRepository salesRepo;

    @Autowired
    private PurchaseOrderRepository purchaseRepo;

    @Autowired
    private ProductRepository productRepo;

    // SALES REPORT
    public List<SalesOrder> getSalesReport() {
        return salesRepo.findAll();
    }

    // PURCHASE REPORT
    public List<PurchaseOrder> getPurchaseReport() {
        return purchaseRepo.findAll();
    }

    // STOCK ALERT
    public List<Product> getLowStockProducts() {

        int threshold = 10;

        return productRepo.findAll()
                .stream()
                .filter(p -> p.getStockQuantity() < threshold)
                .toList();
    }

    // SALES BY DATE
    public List<SalesOrder> salesByDate(LocalDate startDate, LocalDate endDate) {
        return salesRepo.findAll()
                .stream()
                .filter(order ->
                        order.getOrderDate() != null &&
                        !order.getOrderDate().isBefore(startDate) &&
                        !order.getOrderDate().isAfter(endDate))
                .toList();
    }
}