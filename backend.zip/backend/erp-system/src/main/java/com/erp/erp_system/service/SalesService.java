package com.erp.erp_system.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.erp_system.entity.Customer;
import com.erp.erp_system.entity.Inventory;
import com.erp.erp_system.entity.Product;
import com.erp.erp_system.entity.SalesItem;
import com.erp.erp_system.entity.SalesOrder;
import com.erp.erp_system.repository.CustomerRepository;
import com.erp.erp_system.repository.InventoryRepository;
import com.erp.erp_system.repository.ProductRepository;
import com.erp.erp_system.repository.SalesOrderRepository;

@Service
public class SalesService {

    @Autowired
    private SalesOrderRepository orderRepo;

    @Autowired
    private InventoryRepository inventoryRepo;

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private CustomerRepository customerRepo;

    public SalesOrder createOrder(Long customerId, List<SalesItem> items){

        Customer customer = customerRepo.findById(customerId).orElseThrow();

        SalesOrder order = new SalesOrder();
        order.setOrderDate(LocalDate.now());
        order.setCustomer(customer);

        double total = 0;

        for(SalesItem item : items){

            Product product = productRepo.findById(item.getProduct().getId()).orElseThrow();

            Inventory inventory = inventoryRepo.findByProduct(product).orElseThrow();

            if(inventory.getQuantity() < item.getQuantity()){
                throw new RuntimeException("Stock not available");
            }

            inventory.setQuantity(
                    inventory.getQuantity() - item.getQuantity()
            );

            inventoryRepo.save(inventory);

            item.setProduct(product);
            item.setSalesOrder(order);

            total += product.getPrice() * item.getQuantity();
        }

        order.setItems(items);
        order.setTotalAmount(total);

        return orderRepo.save(order);
    }

	public SalesOrder saveOrder(SalesOrder order) {
		// TODO Auto-generated method stub
		return null;
	}
}