package com.erp.erp_system.controller;

import java.io.ByteArrayInputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.erp.erp_system.entity.Invoice;
import com.erp.erp_system.repository.InvoiceRepository;
import com.erp.erp_system.service.InvoiceService;
import com.erp.erp_system.service.PdfService;

@RestController
@RequestMapping("/api/invoice")
public class InvoiceController {

    @Autowired
    private InvoiceService service;

    @Autowired
    private PdfService pdfService;

    @Autowired
    private InvoiceRepository invoiceRepo;

    /**
     * Generate invoice from sales order
     */
    @PostMapping("/{salesOrderId}")
    public Invoice create(@PathVariable Long salesOrderId){

        return service.generateInvoice(salesOrderId);
    }

    /**
     * Get invoice details
     */
    @GetMapping("/{invoiceId}")
    public Invoice getInvoice(@PathVariable Long invoiceId){

        return invoiceRepo.findById(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));
    }

    /**
     * Download invoice PDF
     */
    @GetMapping("/pdf/{invoiceId}")
    public ResponseEntity<InputStreamResource> download(@PathVariable Long invoiceId){

        Invoice invoice = invoiceRepo.findById(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));

        ByteArrayInputStream pdf = pdfService.generateInvoicePdf(invoice);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=invoice_" + invoiceId + ".pdf");

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(pdf));
    }
}