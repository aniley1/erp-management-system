package com.erp.erp_system.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.erp_system.entity.Supplier;
import com.erp.erp_system.repository.SupplierRepository;

@Service
public class SupplierService {
	@Autowired
    private SupplierRepository repo;

    public List<Supplier> getAllSupplier(){
        return repo.findAll();
    }

    public Supplier save(Supplier s){
        return repo.save(s);
    }

    public void delete(Long id){
        repo.deleteById(id);
    }
}
