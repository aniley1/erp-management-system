package com.erp.erp_system.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.erp_system.dto.*;
import com.erp.erp_system.entity.*;
import com.erp.erp_system.repository.*;

@Service
public class GRNService {

    @Autowired
    private GRNRepository grnRepo;

    @Autowired
    private PurchaseOrderRepository purchaseOrderRepo;

    @Autowired
    private ProductRepository productRepo;

    public GRN createGRN(GRNRequest request){

        PurchaseOrder po = purchaseOrderRepo
                .findById(request.getPurchaseOrderId())
                .orElseThrow();

        GRN grn = new GRN();
        grn.setPurchaseOrder(po);
        grn.setReceivedDate(LocalDate.now());

        List<GRNItem> items = new ArrayList<>();

        for(GRNItemRequest i : request.getItems()){

            Product product = productRepo
                    .findById(i.getProductId())
                    .orElseThrow();

            GRNItem item = new GRNItem();
            item.setGrn(grn);
            item.setProduct(product);
            item.setQuantityReceived(i.getQuantityReceived());

            // STOCK UPDATE
            product.setStockQuantity(product.getStockQuantity() + i.getQuantityReceived());
            productRepo.save(product);

            items.add(item);
        }

        grn.setItems(items);

        return grnRepo.save(grn);
    }

    public List<GRN> getAll(){
        return grnRepo.findAll();
    }
}