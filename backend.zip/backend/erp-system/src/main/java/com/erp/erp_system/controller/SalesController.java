package com.erp.erp_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.erp.erp_system.entity.SalesItem;
import com.erp.erp_system.entity.SalesOrder;
import com.erp.erp_system.service.SalesService;

@RestController
@RequestMapping("/api/sales")
public class SalesController {

    @Autowired
    private SalesService service;

    @PostMapping("/{customerId}")
    public SalesOrder create(@PathVariable Long customerId,
                             @RequestBody List<SalesItem> items){

        return service.createOrder(customerId, items);
    }
}