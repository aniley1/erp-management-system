package com.erp.erp_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.erp.erp_system.dto.GRNRequest;
import com.erp.erp_system.entity.GRN;
import com.erp.erp_system.service.GRNService;

@RestController
@RequestMapping("/api/grns")
public class GRNController {

    @Autowired
    private GRNService service;

    @PostMapping
    public GRN create(@RequestBody GRNRequest request){
        return service.createGRN(request);
    }

    @GetMapping
    public List<GRN> getAll(){
        return service.getAll();
    }
}