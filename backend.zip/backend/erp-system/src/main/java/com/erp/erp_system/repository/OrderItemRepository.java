package com.erp.erp_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erp.erp_system.entity.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {

}