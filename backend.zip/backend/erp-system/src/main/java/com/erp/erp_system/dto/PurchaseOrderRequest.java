package com.erp.erp_system.dto;

import java.util.List;

public class PurchaseOrderRequest {

    private Long supplierId;

    private List<PurchaseItemRequest> items;

	public Long getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(Long supplierId) {
		this.supplierId = supplierId;
	}

	public List<PurchaseItemRequest> getItems() {
		return items;
	}

	public void setItems(List<PurchaseItemRequest> items) {
		this.items = items;
	}

    // getters setters
}