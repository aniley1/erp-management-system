package com.erp.erp_system.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.erp.erp_system.entity.Supplier;
import com.erp.erp_system.service.SupplierService;

@RestController
@RequestMapping("/api/suppliers")
public class SupplierController {

    @Autowired
    private SupplierService service;

    @GetMapping
    public List<Supplier> getAll(){
        return service.getAllSupplier();
    }

    @PostMapping
    public Supplier create(@RequestBody Supplier s){
        return service.save(s);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id){
        service.delete(id);
    }
}