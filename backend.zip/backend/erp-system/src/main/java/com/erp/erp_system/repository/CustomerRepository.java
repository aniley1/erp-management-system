package com.erp.erp_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erp.erp_system.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
}