package com.erp.erp_system.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erp.erp_system.dto.PurchaseItemRequest;
import com.erp.erp_system.dto.PurchaseOrderRequest;
import com.erp.erp_system.entity.*;
import com.erp.erp_system.repository.*;

@Service
public class PurchaseOrderService {

    @Autowired
    private PurchaseOrderRepository purchaseOrderRepo;

    @Autowired
    private PurchaseOrderItemRepository itemRepo;

    @Autowired
    private SupplierRepository supplierRepo;

    @Autowired
    private ProductRepository productRepo;

    public PurchaseOrder createOrder(PurchaseOrderRequest request){

        Supplier supplier = supplierRepo.findById(request.getSupplierId()).orElseThrow();

        PurchaseOrder order = new PurchaseOrder();
        order.setOrderDate(LocalDate.now());
        order.setSupplier(supplier);

        List<PurchaseOrderItem> items = new ArrayList<>();

        double total = 0;

        for(PurchaseItemRequest i : request.getItems()){

            Product product = productRepo.findById(i.getProductId()).orElseThrow();

            PurchaseOrderItem item = new PurchaseOrderItem();
            item.setProduct(product);
            item.setQuantity(i.getQuantity());
            item.setPrice(product.getPrice());

            item.setPurchaseOrder(order);

            total += product.getPrice() * i.getQuantity();

            items.add(item);
        }

        order.setItems(items);
        order.setTotalAmount(total);

        return purchaseOrderRepo.save(order);
    }

	public PurchaseOrderItemRepository getItemRepo() {
		return itemRepo;
	}

	public void setItemRepo(PurchaseOrderItemRepository itemRepo) {
		this.itemRepo = itemRepo;
	}
}