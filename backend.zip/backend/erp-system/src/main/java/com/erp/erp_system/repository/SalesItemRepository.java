package com.erp.erp_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erp.erp_system.entity.SalesItem;

public interface SalesItemRepository extends JpaRepository<SalesItem,Long>{

}