package com.erp.erp_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erp.erp_system.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

}