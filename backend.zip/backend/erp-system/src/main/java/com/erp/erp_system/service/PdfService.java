package com.erp.erp_system.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import org.springframework.stereotype.Service;

import com.erp.erp_system.entity.Invoice;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class PdfService {

    public ByteArrayInputStream generateInvoicePdf(Invoice invoice){

        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try{

            PdfWriter.getInstance(document, out);
            document.open();

            document.add(new Paragraph("ERP Invoice"));
            document.add(new Paragraph("Invoice ID: " + invoice.getId()));
            document.add(new Paragraph("Date: " + invoice.getInvoiceDate()));
            document.add(new Paragraph("Amount: " + invoice.getAmount()));

            document.close();

        }catch(Exception e){
            e.printStackTrace();
        }

        return new ByteArrayInputStream(out.toByteArray());
    }
}