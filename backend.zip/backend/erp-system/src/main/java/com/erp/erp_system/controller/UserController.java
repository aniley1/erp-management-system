package com.erp.erp_system.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.erp.erp_system.dto.UserRegisterRequest;
import com.erp.erp_system.entity.User;
import com.erp.erp_system.service.UserService;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public User registerUser(@RequestBody UserRegisterRequest request) {

        return userService.registerUser(
                request.getName(),
                request.getEmail(),
                request.getPassword(),
                request.getRoleId()
        );
    }
}