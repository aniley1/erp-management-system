package com.erp.erp_system.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erp.erp_system.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

    User findByEmail(String email);
}