package com.erp.erp_system.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.erp.erp_system.entity.Inventory;
import com.erp.erp_system.entity.Product;

public interface InventoryRepository extends JpaRepository<Inventory, Long>{

    Optional<Inventory> findByProduct(Product product);
    
    @Query("SELECT i FROM Inventory i WHERE i.quantity < i.threshold")
    List<Inventory> findLowStock();
}