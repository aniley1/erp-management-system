package com.erp.erp_system.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.erp.erp_system.entity.SalesOrder;
import com.erp.erp_system.repository.SalesOrderRepository;

public class SalesServiceTest {

    @Mock
    private SalesOrderRepository repository;

    @InjectMocks
    private SalesService service;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveSalesOrder() {

        SalesOrder order = new SalesOrder();

        when(repository.save(order)).thenReturn(order);

        SalesOrder saved = repository.save(order);   // 👈 direct mock call

        assertNotNull(saved);
    }
}