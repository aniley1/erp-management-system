package com.erp.erp_system.service;

import com.erp.erp_system.entity.Invoice;
import com.erp.erp_system.repository.InvoiceRepository;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class InvoiceServiceTest {

    @Mock
    private InvoiceRepository invoiceRepository;

    @InjectMocks
    private InvoiceService invoiceService;

    @Test
    void testSaveInvoice() {

        Invoice invoice = new Invoice();
        invoice.setAmount(10000.0);

        when(invoiceRepository.save(invoice)).thenReturn(invoice);

        Invoice saved = invoiceService.save(invoice);

        assertNotNull(saved);
        assertEquals(10000.0, saved.getAmount());

        verify(invoiceRepository, times(1)).save(invoice);
    }
}